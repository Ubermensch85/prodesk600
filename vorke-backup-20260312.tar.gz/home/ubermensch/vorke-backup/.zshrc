# ============================================================
# OH MY ZSH CONFIGURATION
# ============================================================
export ZSH="$HOME/.oh-my-zsh"

# Tema: lasciamo robbyrussell di default, custom prompt dopo
ZSH_THEME="robbyrussell"

# Plugin essenziali
plugins=(
    git
    sudo
    command-not-found
    colored-man-pages
    history
    copypath
    copyfile
    dirhistory
)

# Carica OMZ
source $ZSH/oh-my-zsh.sh

# ============================================================
# PLUGIN AGGIUNTIVI (caricati dopo OMZ)
# ============================================================
# Autosuggestions
if [ -f ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions/zsh-autosuggestions.plugin.zsh ]; then
    source ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-autosuggestions/zsh-autosuggestions.plugin.zsh
    export ZSH_AUTOSUGGEST_HIGHLIGHT_STYLE="fg=8,underline"
    export ZSH_AUTOSUGGEST_STRATEGY=(history completion)
    bindkey '^ ' autosuggest-accept
    bindkey '^f' autosuggest-accept
fi

# Syntax highlighting (DEVE essere ultimo)
if [ -f ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.plugin.zsh ]; then
    source ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-syntax-highlighting/zsh-syntax-highlighting.plugin.zsh
fi

# History substring search
if [ -f ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-history-substring-search/zsh-history-substring-search.plugin.zsh ]; then
    source ${ZSH_CUSTOM:-~/.oh-my-zsh/custom}/plugins/zsh-history-substring-search/zsh-history-substring-search.plugin.zsh
    bindkey '^[[A' history-substring-search-up
    bindkey '^[[B' history-substring-search-down
fi

# ============================================================
# HISTORY CONFIGURATION
# ============================================================
HISTSIZE=50000
SAVEHIST=50000
HISTFILE=~/.zsh_history

setopt EXTENDED_HISTORY
setopt HIST_EXPIRE_DUPS_FIRST
setopt HIST_IGNORE_DUPS
setopt HIST_IGNORE_ALL_DUPS
setopt HIST_FIND_NO_DUPS
setopt HIST_SAVE_NO_DUPS
setopt HIST_REDUCE_BLANKS
setopt SHARE_HISTORY
setopt HIST_VERIFY
setopt APPEND_HISTORY
setopt INC_APPEND_HISTORY

# ============================================================
# COMPLETION
# ============================================================
autoload -Uz compinit && compinit -C

zstyle ':completion:*' menu select
zstyle ':completion:*' matcher-list 'm:{a-zA-Z}={A-Za-z}'
zstyle ':completion:*' list-colors "${(s.:.)LS_COLORS}"
zstyle ':completion:*' verbose yes
zstyle ':completion:*' group-name ''
zstyle ':completion:*:descriptions' format '%B%d%b'
zstyle ':completion:*:warnings' format 'No matches for: %d'

setopt COMPLETE_IN_WORD
setopt ALWAYS_TO_END

# ============================================================
# FZF
# ============================================================
[ -f /usr/share/doc/fzf/examples/key-bindings.zsh ] && source /usr/share/doc/fzf/examples/key-bindings.zsh

export FZF_DEFAULT_OPTS='--height 40% --layout=reverse --border --info=inline'
export FZF_CTRL_T_OPTS="--preview 'batcat --style=numbers --color=always {} 2>/dev/null || cat {}'"
export FZF_ALT_C_OPTS="--preview 'eza --tree --color=always {} 2>/dev/null | head -200'"

# ============================================================
# PROMPT CUSTOM (Sostituisce quello OMZ)
# ============================================================
# Disabilita prompt OMZ e usa custom

autoload -Uz vcs_info
zstyle ':vcs_info:*' enable git
zstyle ':vcs_info:git:*' formats '(%b)'
precmd() { vcs_info }

CYAN='%F{cyan}'
YELLOW='%F{yellow}'
GREEN='%F{green}'
BLUE='%F{blue}'
MAGENTA='%F{magenta}'
RESET='%f'

setopt PROMPT_SUBST
PROMPT='${CYAN}%m${RESET} ${YELLOW}%~${RESET} ${GREEN}>${BLUE}>${MAGENTA}>${RESET} '
RPROMPT='${vcs_info_msg_0_}'

# Titolo
precmd() { 
    print -Pn "\e]0;%n@%m: %~\a"
    vcs_info
}

# ============================================================
# ALIASES
# ============================================================
# ls
if command -v eza &> /dev/null; then
    alias ls='eza --color=auto --icons'
    alias ll='eza -lh --git --icons'
    alias la='eza -lah --git --icons'
    alias lt='eza -lh --sort=modified --icons'
    alias tree='eza --tree --icons'
else
    alias ls='ls --color=auto'
    alias ll='ls -lhF'
    alias la='ls -AlhF'
    alias l='ls -CF'
    alias lt='ls -lhFt'
    alias ltr='ls -lhFtr'
fi

# Navigation
alias ..='cd ..'
alias ...='cd ../..'
alias ....='cd ../../..'

# Safety
alias rm='rm -i'
alias cp='cp -i'
alias mv='mv -i'

# Utilities
alias df='df -h'
alias du='du -h'
alias free='free -h'
alias psg='ps aux | grep -v grep | grep -i -e VSZ -e'
alias h='history'
alias hgrep='history | grep'

# System
alias update='sudo apt update && sudo apt dist-upgrade -y && sudo apt autoclean && sudo apt autoremove --purge -y'
alias cleanup='sudo apt autoremove -y && sudo apt autoclean'

# Network
alias ports='netstat -tulanp'
alias myip='curl -s ifconfig.me'
alias ping='ping -c 5'

# DNS
alias checkdns='sudo systemctl status dnscrypt-custom pihole-FTL'

# Zsh
alias reload='source ~/.zshrc'
alias zshconfig='nano ~/.zshrc'

# ============================================================
# FUNCTIONS
# ============================================================
mkcd() { mkdir -p "$1" && cd "$1"; }

extract() {
    if [ -f "$1" ]; then
        case "$1" in
            *.tar.bz2)   tar xjf "$1"     ;;
            *.tar.gz)    tar xzf "$1"     ;;
            *.bz2)       bunzip2 "$1"     ;;
            *.rar)       unrar x "$1"     ;;
            *.gz)        gunzip "$1"      ;;
            *.tar)       tar xf "$1"      ;;
            *.tbz2)      tar xjf "$1"     ;;
            *.tgz)       tar xzf "$1"     ;;
            *.zip)       unzip "$1"       ;;
            *.Z)         uncompress "$1"  ;;
            *.7z)        7z x "$1"        ;;
            *)           echo "'$1' cannot be extracted" ;;
        esac
    else
        echo "'$1' is not a valid file"
    fi
}

killp() {
    ps aux | grep -i "$1" | grep -v grep | awk '{print $2}' | xargs -r sudo kill -9
}

# ============================================================
# KEY BINDINGS
# ============================================================
bindkey '^r' fzf-history-widget
bindkey '^x^e' edit-command-line
bindkey '^u' backward-kill-line
bindkey '^k' kill-line
bindkey '^a' beginning-of-line
bindkey '^e' end-of-line
bindkey '^[[H' beginning-of-line
bindkey '^[[F' end-of-line
bindkey '^[[3~' delete-char

# ============================================================
# MISC
# ============================================================
setopt NO_BEEP
setopt AUTO_CD
setopt CORRECT
setopt CORRECT_ALL
setopt NO_CASE_GLOB
setopt EXTENDED_GLOB

# MOTD
#echo "Welcome to $(hostname) | $(uname -r) | $(uptime -p 2>/dev/null || uptime)"
