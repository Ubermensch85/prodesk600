#!/bin/bash
# Fan control Vorke V1 Plus
# Accende/spegne la ventola in base alla temperatura con hysteresis

TEMP_ON=55     # °C: accende ventola
TEMP_OFF=45    # °C: spegne ventola
COOLING_DEV="/sys/class/thermal/cooling_device5/cur_state"
SLEEP=5        # secondi tra un controllo e l'altro

while true; do
    # Legge temperatura CPU
    temp=$(cat /sys/class/thermal/thermal_zone0/temp)
    temp=$((temp/1000))

    # Legge stato ventola
    fan_rpm=$(cat /sys/class/hwmon/hwmon1/fan1_input)

    echo "$(date) - Temp: ${temp}°C, Fan RPM: $fan_rpm"

    # Controllo accensione/spegnimento con hysteresis
    if [ "$temp" -ge "$TEMP_ON" ]; then
        # accende ventola se spenta
        current=$(cat "$COOLING_DEV")
        if [ "$current" -eq 0 ]; then
            echo 1 > "$COOLING_DEV"
            echo "$(date) - Fan ON"
        fi
    elif [ "$temp" -le "$TEMP_OFF" ]; then
        # spegne ventola se accesa
        current=$(cat "$COOLING_DEV")
        if [ "$current" -eq 1 ]; then
            echo 0 > "$COOLING_DEV"
            echo "$(date) - Fan OFF"
        fi
    fi

    sleep $SLEEP
done
